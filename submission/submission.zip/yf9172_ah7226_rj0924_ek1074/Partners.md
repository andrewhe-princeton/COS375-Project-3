# COS375 Project 3

### Group

- [Yu-Wei Fan - yf9172: yf9172@princeton.edu]
- [Andrew He - ah7226: andrewhe@princeton.edu]
- [Rishabh Jain - rj0924: jainr@princeton.edu]
- [Eric Kurkowski - ek1074: ek1074@princeton.edu]

## Time Investment

### Approximately how many hours did it take you to complete this assignment?

- Number of hours: 25 hours

### How many additional test cases did you write to test your implementation?

- Number of test cases: 15

## Challenges Encountered

### Did you encounter any serious problems? If yes, please describe (e.g spec was unclear).

- No
- [If yes, please describe the problems encountered]

## Additional Comments

### Write any other comments here.

- [comment_1]
- [comment_2]

## Help Information

## Generative AI.

- If you used generative AI for help with this project, please describe what how you used it.
- Also describe how you tested any generated code/designs for correctness, and your rationale for its completeness.
- Write "N/A" if you did not use generative AI for any help during this project.

Some of the hazards detection logic is generated with the help of GPT/Copilot.

We modified/checked the code manually and the correctness is ensured by testing it on the generated test cases.

## Acknowledgement of Original Work

### Write and sign the following student acknowledgment of original work.

> For your signature, type /s/, followed by your name.
> 
> Here is an example:
>
>> This programming assignment represents my own work in accordance with University regulations and the course syllabus.  /s/ Ada Lovelace

- [Acknowledgement of student 1]
This programming assignment represents my own work in accordance with University regulations and the course syllabus.  /s/ Yu-Wei Fan
- [Acknowledgement of student 2]
This programming assignment represents my own work in accordance with University regulations and the course syllabus.  /s/ Andrew He
- [Acknowledgement of student 3]
This programming assignment represents my own work in accordance with University regulations and the course syllabus.  /s/ Rishabh Jain
- [Acknowledgement of student 4]
This programming assignment represents my own work in accordance with University regulations and the course syllabus.  /s/ Eric Kurkowski
